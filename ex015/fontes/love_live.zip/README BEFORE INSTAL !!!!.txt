English

By downloading and installing this font, you agree that the only font you install that you download is the "FREE PERSONAL USE" font that is "Non-Commercial".
and if you use the font on a "Commercial", there will be consequences for paying according to the license you are using.

Full License Here : https://www.creativefabrica.com/product/love-live-3/ref/379016/
for Donation Paypal : hatftype@gmail.com

1. This font is ONLY FOR PERSONAL USE.
2. NO COMMERCIAL USE ALLOWED.
3. You are REQUIRES A LICENSE for PROMOTIONAL or COMMERCIAL USE.
4. CONTACT ME before any Promotional or Commercial Use.

Support email:
hatftype@gmail.com

Thanks



Indonesia

Dengan mengunduh dan menginstal font ini, anda setuju bahwa satu-satunya font yang anda instal yang anda unduh adalah font "PENGGUNAAN PRIBADI GRATIS" yaitu "Non-Komersial".
dan jika anda menggunakan font berdasarkan "Komersial", akan ada konsekuensi untuk membayar sesuai dengan lisensi yang anda gunakan.

1. Font ini HANYA UNTUK PENGGUNAAN PRIBADI.
2. TANPA PENGGUNAAN KOMERSIAL DIPERBOLEHKAN.
3. Anda MEMBUTUHKAN LISENSI untuk PENGGUNAAN PROMOSI atau KOMERSIAL.
4. HUBUNGI SAYA sebelum Penggunaan Promosi atau Komersial.



Email dukungan:
hatftype@gmail.com

Terima Kasih

